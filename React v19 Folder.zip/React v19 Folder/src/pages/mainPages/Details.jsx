// src/pages/Details.jsx
import React from "react";
import { useParams } from "react-router-dom"; // Use useParams to grab dynamic params

const Details = () => {
   const { id } = useParams(); // Access the dynamic `id` parameter

  return (
    <div>
      <h1 className="text-3xl">Details for Item {id}</h1>
      <p>This is the detailed content for item with ID: {id}.</p>
    </div>
  );
};

export default Details;
