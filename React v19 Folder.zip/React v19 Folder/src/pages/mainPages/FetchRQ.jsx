// src/pages/FetchRQ.jsx
import React from "react";
import { Link } from "react-router-dom"; // Use Link for navigation

const FetchRQ = () => {
  return (
    <div>
      <h1 className="text-3xl">React Query Data</h1>
      <ul>
        <li>
          <Link to="/details/1" className="text-blue-600">
            Go to Item 1
          </Link>
        </li>
        <li>
          <Link to="/details/2" className="text-blue-600">
            Go to Item 2
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default FetchRQ;
