import React from 'react'

function Button() {
    return (
        <div>
            Button
Button
        </div>
    )
}

export default Button
