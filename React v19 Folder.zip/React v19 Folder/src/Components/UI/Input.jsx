import React from 'react'

function Input() {
    return (
        <div>
            Input
Input
        </div>
    )
}

export default Input
