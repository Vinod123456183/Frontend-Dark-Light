import React from "react";

function HomePage() {
  return <div>HomePage HomePage</div>;
}

export default HomePage;
