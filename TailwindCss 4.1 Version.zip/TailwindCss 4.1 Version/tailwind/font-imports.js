export default{
    @import url("https://fonts.googleapis.com/css2?family=Courier+Prime:wght@400;700&family=Peignior+Sans+Serif&family=North+Culture&family=Compel+Geometric&family=Fibon+Sans&family=Kanakira&family=Gemsbuck&family=Theater+Bold+Sans+Serif&family=Tulisans&family=Fresty+Script&display=swap");
    @import url("https://fonts.googleapis.com/css2?family=Aboreto&family=Bodoni+Moda+SC:ital,opsz,wght@0,6..96,400..900;1,6..96,400..900&family=Bruno+Ace+SC&family=Castoro+Titling&family=Courier+Prime:ital,wght@0,400;0,700;1,400;1,700&family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&family=Julius+Sans+One&family=League+Spartan:wght@100..900&family=Michroma&family=Montserrat:ital,wght@0,100..900;1,100..900&family=Nerko+One&family=Orbitron:wght@400..900&family=PT+Mono&display=swap");
    @import url("https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100..900;1,100..900&display=swap");
    @import url("https://fonts.googleapis.com/css2?family=Mona+Sans:ital,wght@0,200..900;1,200..900&display=swap");
    @import url("https://db.onlinewebfonts.com/c/16436b1f829fb58083d4b697dd9ef972?family=Signature+Collection");
}