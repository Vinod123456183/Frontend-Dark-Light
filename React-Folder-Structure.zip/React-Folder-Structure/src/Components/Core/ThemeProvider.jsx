import React from "react";

function ThemeProvider() {
  return <div>ThemeProvider ThemeProvider</div>;
}

export default ThemeProvider;
