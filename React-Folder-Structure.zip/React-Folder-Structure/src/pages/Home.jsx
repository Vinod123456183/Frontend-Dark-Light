import React from 'react'

function Home() {
    return (
        <div>
Home
Home            
        </div>
    )
}

export default Home
