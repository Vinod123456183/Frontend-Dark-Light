import React from 'react'

function Routes() {
  return (
    <div>Routes</div>
  )
}

export default Routes