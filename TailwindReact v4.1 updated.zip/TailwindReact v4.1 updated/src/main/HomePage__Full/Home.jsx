import React from "react";
import tt from "../../../tailwind/tailwind-css-colors";

function Home() {
  return <div className="page-container   ">Home</div>;
}

export default Home;
